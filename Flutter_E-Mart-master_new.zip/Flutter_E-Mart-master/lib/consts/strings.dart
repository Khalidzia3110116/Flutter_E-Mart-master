const appname = "Eco-Style Collective";
const appversion = "Version 3.0.0";
const credits = "@lpacheno @rts";
const emailHint  =  "Email";
const email  =  "example@gmail.com";
const password  =  "Password";
const passwordHint  =  "*********";
const retypePassword = "Retype Password";
const name = "Name" ;
const nameHint = "@lpacheno @rts" ;
const forgetpassword  =  "Forget Password";
const login = "LOGIN";
const loggedin = "Logged in successfully";
const loggedout = "Logged out successfully";
const logout = "Logout";
const signup = "SIGNUP";
const createNewAccount = "or, create a new account";
const loginWith = 'Log in With';
const PrivacyPolicy = 'Privacy Policy';
const TermAndCondition = "Terms and Conditions";
const alreadyHaveAccount = "Already have an account?";
const home = "Home", categories = "Categories", cart = "Cart", account = "Account";



const searchanything = "Search anything...",
      todayDeal = "Today's Deal",
      flashsale = "Flash Sale",
      topSellers = "Top Sellers",
      brand = "Brand",
      topCategories = "Top Categoies",
      womenDress = "Women Dress",
      girlsWatches = "Girls Watches",
      girlsDress = "Girls Dress",
      mobilePhone = "Mobile Phone",
      boysGlasses = "Boys Glasses",
      tShirts = "TShirts",
      featuredProducts = "Featured Products",
      featuredCategories = "Featured Categories";


const womenClothing = "Women Clothing",
    menClothingFashion = "Men Clothing & Fashion",
    compAccess = "Computer & Accessories",
    automobile = "Automobile",
    kidtoys = "Kids & Toys",
    sports = "Sports",
    jewelery = "Jewelery",
    cellphone = "Cellphone & Tab",
    furniture = "Furniture";


const video = "Video",
      reviews = "Reviews",
      sellerPolicy = "Seller Policy",
      returnPolicy = "Return Policy",
      supportPolicy = "Support Policy",
      productsYouMayLike = "Products you may also like";


const wishlist = "My Wishlist",
      orders = "My orders",
      messages = "Messages",
      oldpass = 'Old password',
      newpass = 'New password';