## 0.2.1+1

* Adds pub topics to package metadata.
* Updates minimum supported SDK version to Flutter 3.7/Dart 2.19.

## 0.2.1

* Adds `getMedia` method.

## 0.2.0

* Implements initial Linux support.
